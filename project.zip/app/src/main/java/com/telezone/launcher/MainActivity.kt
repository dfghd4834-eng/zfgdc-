package com.telezone.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

class Tile(val title: String, val app: ResolveInfo?, val click: () -> Unit, val onLong: (() -> Unit)? = null)

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var rv: RecyclerView
    private lateinit var hint: TextView
    private lateinit var date: TextView
    private val adapter = Ad()
    private val tiles = mutableListOf<Tile>()
    private val tabViews = mutableListOf<TextView>()
    private var apps = mutableListOf<ResolveInfo>()
    private var tab = 0
    private var cache = LruCache<String, Drawable>(60)
    private val ultra: Boolean get() = sp.getBoolean("ultra", false)
    private val names = arrayOf("التطبيقات", "أفلام", "مسلسلات", "الإعدادات")
    private val walls = listOf(
        "ليل أزرق" to listOf("#0B1220", "#22345C"),
        "غروب" to listOf("#2B1055", "#B24A5A"),
        "غابة" to listOf("#06191A", "#1F5B45"),
        "بنفسجي" to listOf("#150B2E", "#5B2A86"),
        "فحمي" to listOf("#0A0A0A", "#2C2F36")
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun set(k: String): Set<String> = sp.getStringSet(k, emptySet())!!.toSet()
    private fun toggle(k: String, p: String) {
        val s = set(k).toMutableSet(); if (!s.add(p)) s.remove(p)
        sp.edit().putStringSet(k, s).apply()
    }
    private fun pkg(r: ResolveInfo) = r.activityInfo.packageName
    private fun box(color: String, r: Int, stroke: Boolean = false) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat()
        if (stroke) setStroke(dp(2), Color.WHITE)
    }
    private fun txt(s: String, size: Float) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("p", 0)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(56), dp(32), dp(56), dp(16))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(txt("TELEZONE", 22f).apply {
            typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, dp(32), 0)
        })
        names.forEachIndexed { i, n ->
            val t = txt(n, 18f).apply {
                setPadding(dp(18), dp(8), dp(18), dp(8)); isFocusable = true
                setOnFocusChangeListener { v, f ->
                    v.background = if (f) box("#33FFFFFF", 20) else null
                    if (f && tab != i) { tab = i; refresh() }
                    markTabs()
                }
            }
            tabViews += t; head.addView(t)
        }
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        date = txt("", 14f)
        val clock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        clock.addView(TextClock(this).apply {
            format12Hour = "h:mm a"; format24Hour = "h:mm a"; textSize = 22f; setTextColor(Color.WHITE)
        })
        clock.addView(date)
        head.addView(clock)
        root.addView(head)

        hint = txt("اضغط مطوّلًا على زر OK فوق أي تطبيق في قسم «التطبيقات» ثم اختر إضافته إلى هذا القسم", 16f).apply {
            visibility = View.GONE; setPadding(0, dp(40), 0, 0)
        }
        root.addView(hint)
        rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 5)
            adapter = this@MainActivity.adapter
            itemAnimator = null; clipChildren = false; clipToPadding = false
        }
        root.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(24) })
        setContentView(root)
        tabViews[0].requestFocus()
    }

    override fun onResume() {
        super.onResume()
        cache.evictAll(); cache = LruCache(if (ultra) 24 else 60)
        date.text = SimpleDateFormat("EEEE d MMMM", Locale("ar")).format(Date())
        loadApps(); applyBg(); refresh()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (i.hasCategory(Intent.CATEGORY_HOME)) { tabViews[0].requestFocus(); rv.scrollToPosition(0) }
    }

    @Deprecated("launcher ignores back")
    override fun onBackPressed() {}

    private fun markTabs() = tabViews.forEachIndexed { i, t -> t.alpha = if (i == tab) 1f else 0.6f }

    private fun applyBg() {
        root.background = if (ultra) ColorDrawable(Color.parseColor("#101418")) else
            GradientDrawable(GradientDrawable.Orientation.TL_BR,
                walls[sp.getInt("wall", 0) % walls.size].second.map { Color.parseColor(it) }.toIntArray())
    }

    private fun loadApps() {
        val pm = packageManager
        val m = LinkedHashMap<String, ResolveInfo>()
        for (c in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER))
            for (r in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(c), 0)) {
                val p = pkg(r); if (p != packageName && p !in m) m[p] = r
            }
        val order = (sp.getString("order", "") ?: "").split(",")
        apps = m.values.sortedWith(compareBy<ResolveInfo>(
            { val i = order.indexOf(pkg(it)); if (i < 0) Int.MAX_VALUE else i },
            { it.loadLabel(pm).toString() })).toMutableList()
    }

    private fun current(): List<ResolveInfo> {
        val hidden = set("hidden")
        val l = apps.filter { pkg(it) !in hidden }
        return when (tab) {
            1 -> l.filter { pkg(it) in set("movies") }
            2 -> l.filter { pkg(it) in set("series") }
            else -> l
        }
    }

    private fun refresh() {
        tiles.clear()
        if (tab == 3) {
            val w = sp.getInt("wall", 0) % walls.size
            tiles += Tile("الخلفية: ${walls[w].first}", null, {
                sp.edit().putInt("wall", (w + 1) % walls.size).apply(); applyBg(); refresh() })
            tiles += Tile("وضع الأداء الفائق: ${if (ultra) "مفعّل" else "معطّل"}", null, {
                sp.edit().putBoolean("ultra", !ultra).apply()
                cache.evictAll(); cache = LruCache(if (ultra) 24 else 60); applyBg(); refresh() })
            tiles += Tile("جعل TELEZONE الواجهة الرئيسية", null, {
                try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (e: Exception) {
                    Toast.makeText(this, "اضغط زر Home في الريموت ثم اختر TELEZONE و«دائمًا»", Toast.LENGTH_LONG).show() } })
            tiles += Tile("إظهار التطبيقات المخفية", null, {
                sp.edit().putStringSet("hidden", emptySet()).apply(); refresh() })
            tiles += Tile("إعدادات التلفزيون", null, {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) {} })
        } else current().forEach { r ->
            tiles += Tile(r.loadLabel(packageManager).toString(), r, { launch(r) }, { menu(r) })
        }
        hint.visibility = if (tab in 1..2 && tiles.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun launch(r: ResolveInfo) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).setClassName(pkg(r), r.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) { Toast.makeText(this, "تعذّر تشغيل التطبيق", Toast.LENGTH_SHORT).show() }
    }

    private fun move(r: ResolveInfo, d: Int) {
        val cur = current(); val i = cur.indexOf(r); val j = i + d
        if (j !in cur.indices) return
        Collections.swap(apps, apps.indexOf(cur[i]), apps.indexOf(cur[j]))
        sp.edit().putString("order", apps.joinToString(",") { pkg(it) }).apply()
    }

    private fun menu(r: ResolveInfo) {
        val p = pkg(r)
        val opts = arrayOf("تقديم", "تأخير",
            if (p in set("movies")) "إزالة من الأفلام" else "إضافة إلى الأفلام",
            if (p in set("series")) "إزالة من المسلسلات" else "إضافة إلى المسلسلات",
            "إخفاء التطبيق", "معلومات التطبيق")
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(r.loadLabel(packageManager)).setItems(opts) { _, w ->
                when (w) {
                    0 -> move(r, -1); 1 -> move(r, 1)
                    2 -> toggle("movies", p); 3 -> toggle("series", p); 4 -> toggle("hidden", p)
                    5 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p")))
                }
                if (w < 5) refresh()
            }.show()
    }

    private fun icon(a: ResolveInfo): Drawable? {
        val k = pkg(a)
        return cache.get(k) ?: ((if (ultra) null else a.activityInfo.loadBanner(packageManager))
            ?: a.loadIcon(packageManager)).also { if (it != null) cache.put(k, it) }
    }

    inner class H(val v: LinearLayout, val img: ImageView, val tx: TextView) : RecyclerView.ViewHolder(v)

    inner class Ad : RecyclerView.Adapter<H>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int): H {
            val v = LinearLayout(p.context).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8)); minimumHeight = dp(120)
                isFocusable = true; isClickable = true; isLongClickable = true
                layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
                setOnFocusChangeListener { f, has ->
                    f.background = if (has) box("#40FFFFFF", 14, true) else null
                    if (!ultra) { f.scaleX = if (has) 1.06f else 1f; f.scaleY = f.scaleX }
                }
            }
            val img = ImageView(p.context).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            val tx = txt("", 15f).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            v.addView(img, LinearLayout.LayoutParams(-1, dp(96)))
            v.addView(tx, LinearLayout.LayoutParams(-1, -2))
            return H(v, img, tx)
        }

        override fun onBindViewHolder(h: H, i: Int) {
            val t = tiles[i]
            h.tx.text = t.title; h.tx.textSize = if (t.app == null) 18f else 15f
            val a = t.app
            if (a != null) {
                h.img.visibility = View.VISIBLE
                h.img.layoutParams.height = dp(if (ultra) 64 else 96)
                h.img.setImageDrawable(icon(a))
            } else h.img.visibility = View.GONE
            h.v.setOnClickListener { t.click() }
            h.v.setOnLongClickListener { t.onLong?.invoke(); t.onLong != null }
        }

        override fun getItemCount() = tiles.size
    }
}
